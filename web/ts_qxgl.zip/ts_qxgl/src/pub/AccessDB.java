package pub;

import java.sql.*;

public class AccessDB {

	private Connection conn;

	public AccessDB() {
		conn = null;
	}

	public void setDatesource(String ds) {
	}

	public void connect() {
		String url = "jdbc:mysql://localhost:3306/ts_znpw";
		String user = "root";
		String password = "ok";
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(url, user, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public ResultSet select(String sql) throws SQLException {
		if (conn == null)
			connect();
		Statement stmt = conn.createStatement();
		System.out.println(">>:"+sql);
		ResultSet rs = stmt.executeQuery(sql);
		return rs;
	}

	public void update(String sql) throws SQLException {
		if (conn == null)
			connect();
		Statement stmt = conn.createStatement();
		System.out.println(">>:"+sql);
		stmt.executeUpdate(sql);
	}

	public Connection getconn() throws SQLException {
		if (conn == null)
			connect();
		return conn;
	}

	public void closeconn() throws SQLException {
		if (conn != null && !conn.isClosed())
			conn.close();
	}
}
