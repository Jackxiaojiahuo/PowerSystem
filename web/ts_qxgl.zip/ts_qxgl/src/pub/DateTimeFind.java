// Decompiled by Jad v1.5.7g. Copyright 2000 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/SiliconValley/Bridge/8617/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   DateTimeFind.java

package pub;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateTimeFind
{

    private Date dtNow;

    public DateTimeFind()
    {
        dtNow = new Date();
    }

    public String getDateNow(String strSeparator)
    {
        String strDQRQ = DateFormat.getDateInstance().format(dtNow);
        strDQRQ = strDQRQ.replace('-', strSeparator.charAt(0));
        if(strDQRQ.substring(6, 7).equals(strSeparator))
            strDQRQ = strDQRQ.substring(0, 5) + "0" + strDQRQ.substring(5);
        if(strDQRQ.substring(8).length() == 1)
            strDQRQ = strDQRQ.substring(0, 8) + "0" + strDQRQ.substring(8);
        return strDQRQ;
    }

    public String getYearNow()
    {
        String strDQRQ = getDateNow(".");
        String strDQND = strDQRQ.substring(0, 4);
        return strDQND;
    }

    public String getMonthNow()
    {
        String strDQRQ = getDateNow(".");
        String strDQYF = strDQRQ.substring(5, 7);
        if(strDQYF.charAt(0) == '0')
            strDQYF.substring(1);
        return strDQYF;
    }

    public String getSeasonNow()
    {
        String strDQJD = null;
        String strDQRQ = getDateNow(".");
        int intDQYF = Integer.parseInt(strDQRQ.substring(5, 7));
        switch(intDQYF)
        {
        case 1: // '\001'
        case 2: // '\002'
        case 3: // '\003'
            strDQJD = "1";
            break;

        case 4: // '\004'
        case 5: // '\005'
        case 6: // '\006'
            strDQJD = "2";
            break;

        case 7: // '\007'
        case 8: // '\b'
        case 9: // '\t'
            strDQJD = "3";
            break;

        case 10: // '\n'
        case 11: // '\013'
        case 12: // '\f'
            strDQJD = "4";
            break;
        }
        return strDQJD;
    }

    public String getTimeNow()
    {
        String strDQSJ = DateFormat.getTimeInstance().format(dtNow);
        Calendar day = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("HHmmss");
        strDQSJ = sdf.format(day.getTime());
        return strDQSJ;
    }
}
