function pdrq(num1,num2){
		var tdsj1=num1;
		var tdsj2=num2;
		var year="";
		var month="";
		var date="";
		var k=tdsj1.split("-");
		year=k[0];
		month=k[1];
		date=k[2];
		var qsj=Date.UTC(year,month,date);
		var k=tdsj2.split(" ");
		year=k[0].split("-")[0];
		month=k[0].split("-")[1];
		date=k[0].split("-")[2];
		var hsj=Date.UTC(year,month,date);
		if(qsj==hsj){return "t";}else{return "f";}
	}

	function pks(num1,num2){
		var tdsj1=num1;
		var tdsj2=num2;
		var year="";
		var month="";
		var date="";
		var house="";
		var mm="";
		var k=tdsj1.split(" ");
		year=k[0].split("-")[0];
		month=k[0].split("-")[1];
		date=k[0].split("-")[2];
		house=k[1].split(":")[0];
		mm=k[1].split(":")[1];
		
		var qsj=Date.UTC(year,month,date,house,mm);
		var h=tdsj2.split(" ");
		year=h[0].split("-")[0];
		month=h[0].split("-")[1];
		date=h[0].split("-")[2];
		house=h[1].split(":")[0];
		mm=h[1].split(":")[1];
		
		var hsj=Date.UTC(year,month,date,house,mm);
		if(qsj>=hsj){return "f";}else{return "t";}
	}

function show1(){
	if( document.getElementById("bdzmc").value =="" ) 
		{
			alert("��ѡ����վ!");
			return false;
		}
	document.getElementById("xxx").style.display = "block";
}
function show2(){
	document.getElementById("yyy").style.display = "block";
}
function test(id,mc,lx,wz){
	document.getElementById("sbbm").value = id;
	document.getElementById("tdsb").value = mc;
	document.getElementById("sblx").value = lx;
	document.getElementById("sbwz").value = wz;
	document.getElementById("xxx").style.display = "none";
}
function test2(id,mc,lx,wz){
	document.getElementById("sbbm2").value = id;
	document.getElementById("tdsb2").value = mc;
	document.getElementById("sblx2").value = lx;
	document.getElementById("sbwz2").value = wz;
	document.getElementById("yyy").style.display = "none";
}
function ls(ob){
	if(ob.value=="1"){
		document.getElementById("lsid").style.display = "block";
	}else{
		document.getElementById("lsid").style.display = "none";
	}
	document.getElementById("sbbm2").value = "";
	document.getElementById("tdsb2").value = "";
	document.getElementById("sblx2").value = "";
	document.getElementById("sbwz2").value = "";
}




function sj1(time){
		//alert(time);
		var tdsj1 = new Date(time.replace(/-/,"/"));
		var tdsj2 = new Date(tdsj1.getTime() - 60 * 30 * 1000);
		//alert(1);
		document.getElementById("dwtdsj1").value = format(tdsj2.getFullYear()) + "-" + format(tdsj2.getMonth() + 1)
			+ "-" + format(tdsj2.getDate()) + " " + format(tdsj2.getHours()) + ":" + format(tdsj2.getMinutes());
	}
	
	function sj2(time){
		//alert(time);
		var dwtdsj1 = new Date(time.replace(/-/,"/"));
		var dwtdsj2 = new Date(dwtdsj1.getTime() + 60 * 30 * 1000);
		//alert(1);
		document.getElementById("dwtdsj2").value = format(dwtdsj2.getFullYear()) + "-" + format(dwtdsj2.getMonth() + 1)
			+ "-" + format(dwtdsj2.getDate()) + " " + format(dwtdsj2.getHours()) + ":" + format(dwtdsj2.getMinutes());
	}
	
	function format(str){
		if(str>=0 && str <=9){
			return "0" + str;	
		}else{
			return "" + str;			
		}
	}
	function wd1(){
		WdatePicker({
			dateFmt:'yyyy-MM-dd HH:mm',
			onpicked:function(dp){sj1(dp.cal.getDateStr())}
		});	
	}
	function wd2(){
		WdatePicker({
			dateFmt:'yyyy-MM-dd HH:mm',
			onpicked:function(dp){sj2(dp.cal.getDateStr())}
		});	
	}
	function wd3(){
		WdatePicker({
			dateFmt:'yyyy-MM-dd HH:mm'
		});	
	}
	function wd4(){
		WdatePicker({
			dateFmt:'yyyy-MM-dd HH:mm'
		});	
	}
	function wd5(){
		WdatePicker({
			dateFmt:'yyyy-MM-dd'
		});	
	}